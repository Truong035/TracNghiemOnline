﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TracNghiemOnline.Modell;

namespace TracNghiemOnline.Model
{
    public class DanhGia
    {
     public  List<SoLuongChuong> DanhGiaMucDo{ get; set; }
     public KetQuaThi ketQuaThi { get; set; }


    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TracNghiemOnline.Modell;

namespace TracNghiemOnline.Model
{
    public class BoDeThi
    {
     

        public Bo_De BoDeThi1 { get; set; }
        public string LoaiDe1 { get; set ; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TracNghiemOnline.ComMon
{
  static  public class ComMonStants
    {
       public static string UserLogin = "UserLogin";
        public static string ExamQuesTion = "ExamQuesTion";
        public static string ChapterStudy = "ChapterStudy";
        public static string ExamRoom = "ExamRoom";
        public static string OnTap = "OnTap";
        public static string Cauhoi = "Cauhoi";
    }
}